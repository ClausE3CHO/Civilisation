import React from 'react';
import './Civ.css';

import Amplify , { Auth } from 'aws-amplify';
import aws_exports from './aws-exports';
import { withAuthenticator } from 'aws-amplify-react';
import '@aws-amplify/ui/dist/style.css';

Amplify.configure(aws_exports);

function CivGames() {
  return (
    <div>
    <h5> Game table row 1 </h5>
    <h5> Game table row 2 </h5>
    <h5> Game table row 3 </h5>
    </div>
  );
}

function CivPlayers() {
  return (
    <div>
    <h5> Game Players row 1 </h5>
    <h5> Game Players row 2 </h5>
    <h5> Game Players row 3 </h5>
    </div>
  );
}

function Civ() {
  return (
  <div>
  <h3>Civilisation Game Page</h3>
  <h4>Games</h4>
  <CivGames />
  <h4>Players</h4>
  <CivPlayers />
  </div>
  );
}

export default withAuthenticator(Civ, true);
