import React from "react";
import Civ from "./Civ"
import './index.css';
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link,
  Redirect,
  useHistory,
  useLocation
} from "react-router-dom";

// Notice the URL change each time. If you click the back
// button at this point, would you expect to go back to the
// login page? No! You're already logged in. Try it out,
// and you'll see you go back to the page you visited
// just *before* logging in, the public page.

export default function MainMenu() {
  return (
    <Router>
      <div>
        <ul>
          <li>
            <Link to="/NEEIM">Access NEEIM modelling</Link>
          </li>
          <li>
            <Link to="/civilisation">Play Advanced Civilisation</Link>
          </li>
        </ul>

        <Switch>
          <Route path="/NEEIM">
            <NEEIM />
          </Route>
          <Route path="/civilisation">
            <Civ />
          </Route>
       </Switch>
     </div>
   </Router>
  );
}


// A wrapper for <Route> that redirects to the login
// screen if you're not yet authenticated.
function PrivateRoute({ children, ...rest }) {
  return (
    <Route
      {...rest}
      render={({ location }) =>
        /*fakeAuth.isAuthenticated*/ true ? (
          children
        ) : (
          <Redirect
            to={{
              pathname: "/login",
              state: { from: location }
            }}
          />
        )
      }
    />
  );
}

function NEEIM() {
  return (
    <div>
    <h3>NEEIM modelling not yet Available </h3>
    <a class="myButton" > Complain </a>
    </div>
    );
}

