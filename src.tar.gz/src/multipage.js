import React from "react";
import './index.css';
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link,
  Redirect,
  useHistory,
  useLocation
} from "react-router-dom";

// Notice the URL change each time. If you click the back
// button at this point, would you expect to go back to the
// login page? No! You're already logged in. Try it out,
// and you'll see you go back to the page you visited
// just *before* logging in, the public page.

export default function MainMenu() {
  return (
    <Router>
      <div>
        <ul>
          <li>
            <Link to="/NEEIM">Access NEEIM modelling</Link>
          </li>
          <li>
            <Link to="/civilisation">PPlay Advanced Civilisation</Link>
          </li>
        </ul>

        <Switch>
          <Route path="/NEEIM">
            <PublicPage />
          </Route>
          <Route path="/civilisation">
            <Civ />
          </Route>

const fakeAuth = {
  isAuthenticated: false,
  authenticate(cb) {
    fakeAuth.isAuthenticated = true;
    setTimeout(cb, 100); // fake async
  },
  signout(cb) {
    fakeAuth.isAuthenticated = false;
    setTimeout(cb, 100);
  }
};

function AuthButton() {
  let history = useHistory();
  console.log("testing");

  return ( // fakeAuth.isAuthenticated ? (
    <p>
      Welcome!{" "}
      <button
        onClick={() => {
          fakeAuth.signout(() => history.push("/"));
        }}
      >
        Sign out
      </button>
    </p> )
    /*
  ) : (
    <p>You are Not logged in.</p>
  );
    */
}

// A wrapper for <Route> that redirects to the login
// screen if you're not yet authenticated.
function PrivateRoute({ children, ...rest }) {
  return (
    <Route
      {...rest}
      render={({ location }) =>
        fakeAuth.isAuthenticated ? (
          children
        ) : (
          <Redirect
            to={{
              pathname: "/login",
              state: { from: location }
            }}
          />
        )
      }
    />
  );
}

function PublicPage() {
  return <h3>Public</h3>;
}

function ProtectedPage() {
  return <h3>Protected</h3>;
}

function LoginPage() {
  let history = useHistory();
  let location = useLocation();

  let { from } = location.state || { from: { pathname: "/" } };
  let txt = history.location.state.from.pathname ;

  let login = () => {
    fakeAuth.authenticate(() => {
      history.replace(from);
    });
  };

  console.log("history steps " + history.length );
///   txt  += history.location.pathname ;
///  for (let el = 1 ; el < history.length ; el++)  { txt += history.location.pathname + " "  }
    
  return (
    <div>
      <p>You must log in to view the page at<code> {from.pathname} </code> </p>
      <button className="knap" onClick={login}>Log in</button>
      <p> {txt} </p>
    </div>
  );
}
